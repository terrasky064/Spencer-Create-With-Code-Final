# useful_scripts
Various useful scripts for

* Ubuntu 16.04 LTS & Windows 10 19H2 LTSC



### Tools

**It is recommended to run `./setup.sh` for setup in `$HOME/bin` or `$HOME/.bashrc`, then you can use tools like `git_update_batch`, `find_git_repo` and `echo_with_color` directly in the terminal under arbitrary directory. You can easily get instructions for each tools by using `-h` or `--help` after the command. For Windows Run Master and Master2 from the Desktop for easy access. Make sure to enable admin for both the windows and Ubuntu Scripts by selecting "run as admin" for windows from the right-click menu, or by typing "sudo bash scriptname.sh" in terminal, removing the quotations and replacing scriptname.sh with the name and path of the script.**